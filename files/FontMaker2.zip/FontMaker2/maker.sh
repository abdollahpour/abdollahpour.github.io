#!/bin/sh
#
java -jar maker.jar
